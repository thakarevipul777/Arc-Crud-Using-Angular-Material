import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/Services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.scss']
})
export class AddUsersComponent implements OnInit {
  addUserForm : FormGroup =new FormGroup({})
  constructor(private formbuilder:FormBuilder,private api:UserService,private route:Router,private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.addUserForm=this.formbuilder.group({
      'Name':new FormControl('',[Validators.required]),
      'email':new FormControl('',[Validators.required]),
      'phone':new FormControl('',[Validators.required])
    })
  }

  createUser(){

 
    this.api.Adduser(this.addUserForm.value).subscribe(res =>{
      console.log(res);
      this._snackBar.open("The User Was Created Successfully")
    },err =>{
      this._snackBar.open("The User Was Not Created")
    })
    


  }

}
