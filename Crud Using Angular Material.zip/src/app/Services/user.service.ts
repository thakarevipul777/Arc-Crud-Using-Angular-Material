import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

   baseUrl:string="https://jsonplaceholder.cypress.io/"

  constructor(private http:HttpClient) { }

  list(){
    return this.http.get(this.baseUrl  + "users")
  }

  view(id:string){
    return this.http.get(this.baseUrl + "users/" +id)
  }

  Adduser(data:any){
    return this.http.post(this.baseUrl+"users",data)

  }
  delet(id:any){
    return this.http.delete(this.baseUrl+"users/"+id)

  }

  update(id:any,data:any){
    return this.http.put(this.baseUrl+"users/"+id,data)

  }

  
}
