import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.scss']
})
export class ViewUsersComponent implements OnInit {

  constructor(private api:UserService,private router:ActivatedRoute,private route:Router) { }

  ngOnInit(): void {

    // this.Gettingview(this.router.snapshot.params.id)
    this.router.params.subscribe( res=>{
      this.Data=res.id
    })

    this.api.view(this.Data).subscribe(res =>{
      this.User=res
    })

  }

  Data:any;
  User:any

  // Gettingview(id: string){

  //   this.api.view(id).subscribe( res => {
  //     this.Data=res
  //   })

  // }



}
