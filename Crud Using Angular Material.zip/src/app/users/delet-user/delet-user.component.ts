import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-delet-user',
  templateUrl: './delet-user.component.html',
  styleUrls: ['./delet-user.component.scss']
})
export class DeletUserComponent implements OnInit {
  userId:any;
  constructor(private activateroute:ActivatedRoute,private api:UserService,private _snackBar: MatSnackBar,private router:Router) { }

  ngOnInit(): void {
    this.activateroute.params.subscribe(data =>{
      this.userId=data.id
    })

    if(this.userId){
      this.api.delet(this.userId).subscribe(res =>{

        this._snackBar.open("Data Deleted Succesfully");
        this.router.navigate(['/list'])

      },err =>{
        this._snackBar.open("Data was Not Deleted ")
      })
    }

  }

}
