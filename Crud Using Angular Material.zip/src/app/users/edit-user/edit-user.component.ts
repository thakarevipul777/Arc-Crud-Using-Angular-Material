import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit {
  FormEdit:FormGroup=new FormGroup({})
  constructor(private activatedroute:ActivatedRoute,private route:Router,private user:UserService,private  _snackBar: MatSnackBar,private formbuilder:FormBuilder) { }
  userId:any
  userDetail:any;
  load=false;
  ngOnInit(): void {
    this.load=false;
    this.activatedroute.params.subscribe( data =>{
      this.userId=data.id
    })

  

    if(this.userId !== ''){
      this.user.view(this.userId)
      .toPromise()
      .then(data =>{
        this.userDetail=data
        Object.assign(this.userDetail,data)
        console.log(this.userDetail)

        this.FormEdit=this.formbuilder.group({
          username:new FormControl(this.userDetail.name),
          email:new FormControl(this.userDetail.email),
        })


        this.load=true

  
      })
      .catch(err =>{
          console.log(err)
      })

    }
  }

  update(){

    this.user.update(this.userId,this.FormEdit.value).subscribe(res =>{
      console.log(res);
      this._snackBar.open("The User updated Successfully")
    },err =>{
      this._snackBar.open("The User Was not Update")
    })

  }
  

}
