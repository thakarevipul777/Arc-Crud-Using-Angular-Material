import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.scss']
})
export class ListUsersComponent implements OnInit {

   listusers:any;
  constructor(private userservice:UserService,private route:Router) { }

  ngOnInit(): void {

    this.userservice.list().subscribe(res =>{
      this.listusers = res
    })

  }

  // Viewid(id: any){
    
  //   this.route.navigate(['/view',id])
    
  // }

}
